"""Verification: Aer results vs analytic states and an independent NumPy engine.

The NumPy engine below mirrors the algorithm used by the front-end prototype,
so a passing parity test shows the browser demo and the Aer backend agree.
"""
import random
import numpy as np
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)
S2 = 2 ** -0.5
M = {"X": [[0, 1], [1, 0]], "Y": [[0, -1j], [1j, 0]], "Z": [[1, 0], [0, -1]],
     "H": [[S2, S2], [S2, -S2]], "S": [[1, 0], [0, 1j]],
     "T": [[1, 0], [0, complex(S2, S2)]]}


def reference(n, ops):
    s = np.zeros(2 ** n, complex); s[0] = 1
    for o in sorted(ops, key=lambda o: o["col"]):
        if o["g"] == "CX":
            for i in range(len(s)):
                if (i >> o["c"] & 1) and not (i >> o["q"] & 1):
                    j = i | 1 << o["q"]; s[i], s[j] = s[j], s[i]
        else:
            m = np.array(M[o["g"]])
            for i in range(len(s)):
                if not (i >> o["q"] & 1):
                    j = i | 1 << o["q"]; a, b = s[i], s[j]
                    s[i], s[j] = m[0, 0] * a + m[0, 1] * b, m[1, 0] * a + m[1, 1] * b
    return s


def run(n, ops, shots=0):
    r = client.post("/simulate", json={"num_qubits": n, "ops": ops, "shots": shots})
    assert r.status_code == 200, r.text
    return r.json()


def test_health():
    assert client.get("/health").json()["backend"] == "qiskit-aer"


def test_bell_state():
    r = run(2, [{"col": 0, "g": "H", "q": 0}, {"col": 1, "g": "CX", "c": 0, "q": 1}])
    assert r["probabilities"]["00"] == pytest.approx(0.5)
    assert r["probabilities"]["11"] == pytest.approx(0.5)
    assert "01" not in r["probabilities"] and "10" not in r["probabilities"]
    assert all(b["length"] == pytest.approx(0, abs=1e-9) for b in r["bloch"])


def test_bloch_axes():
    r = run(1, [{"col": 0, "g": "H", "q": 0}])               # |+>  -> +x
    assert (r["bloch"][0]["x"], r["bloch"][0]["z"]) == (pytest.approx(1), pytest.approx(0, abs=1e-9))
    r = run(1, [{"col": 0, "g": "H", "q": 0}, {"col": 1, "g": "S", "q": 0}])  # |+i> -> +y
    assert r["bloch"][0]["y"] == pytest.approx(1)
    r = run(1, [{"col": 0, "g": "X", "q": 0}])                # |1> -> -z
    assert r["bloch"][0]["z"] == pytest.approx(-1)


def test_ghz_counts():
    ops = [{"col": 0, "g": "H", "q": 0}, {"col": 1, "g": "CX", "c": 0, "q": 1},
           {"col": 2, "g": "CX", "c": 1, "q": 2}]
    r = run(3, ops, shots=2000)
    assert set(r["counts"]) <= {"000", "111"} and sum(r["counts"].values()) == 2000


def test_random_circuits_match_reference():
    rng = random.Random(7)
    for _ in range(150):
        n = rng.randint(1, 4); ops = []
        for col in range(rng.randint(1, 8)):
            free = list(range(n)); rng.shuffle(free)
            while free and rng.random() < 0.8:
                if n > 1 and len(free) > 1 and rng.random() < 0.3:
                    ops.append({"col": col, "g": "CX", "c": free.pop(), "q": free.pop()})
                else:
                    ops.append({"col": col, "g": rng.choice("XYZHST"), "q": free.pop()})
        got = run(n, ops)["statevector"]
        got = np.array([complex(a, b) for a, b in got])
        assert abs(np.vdot(got, reference(n, ops))) ** 2 == pytest.approx(1, abs=1e-9)


@pytest.mark.parametrize("payload", [
    {"num_qubits": 2, "ops": [{"col": 0, "g": "H", "q": 5}]},                     # out of range
    {"num_qubits": 2, "ops": [{"col": 0, "g": "CX", "q": 1}]},                    # no control
    {"num_qubits": 2, "ops": [{"col": 0, "g": "H", "q": 0}, {"col": 0, "g": "X", "q": 0}]},
    {"num_qubits": 99, "ops": []},
])
def test_rejects_bad_input(payload):
    assert client.post("/simulate", json=payload).status_code == 422


def test_tutor_requires_key(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    r = client.post("/tutor", json={"question": "why?", "context": "Bell state"})
    assert r.status_code == 503


def test_index_served():
    r = client.get("/")
    assert r.status_code == 200 and "Qurious" in r.text


def test_rate_limit_blocks_bursts(monkeypatch):
    import main
    monkeypatch.setattr(main, "RATE_SIMULATE", 3)
    main._hits.clear()
    body = {"num_qubits": 1, "ops": []}
    codes = [client.post("/simulate", json=body).status_code for _ in range(5)]
    assert codes[:3] == [200, 200, 200] and codes[3:] == [429, 429]
    main._hits.clear()
