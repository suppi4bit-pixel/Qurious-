"""Qurious backend (SIH26140): FastAPI + Qiskit Aer.

The circuit format matches the front-end prototype exactly:
  {"num_qubits": 3, "ops": [{"col": 0, "g": "H", "q": 0},
                            {"col": 1, "g": "CX", "c": 0, "q": 1}]}
`q` is the target qubit, `c` the control (CX only), `col` the time step.
Bit order is little-endian like Qiskit: bitstrings read q(n-1) ... q0.
"""
from typing import Literal, Optional

import numpy as np
import collections
import os
import time

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, model_validator
from qiskit import QuantumCircuit
from qiskit.quantum_info import DensityMatrix, partial_trace
from qiskit_aer import AerSimulator

MAX_QUBITS = 10          # keeps request cost bounded on a small server
MAX_OPS = 200
MAX_SHOTS = 20000

app = FastAPI(title="Qurious API", version="0.1.0")
# Same-origin needs no CORS. Set ALLOWED_ORIGINS="https://yourdomain.com" (comma separated)
# only if a different site calls this API; "*" allows everyone (dev only).
_origins = [o.strip() for o in os.getenv(
    "ALLOWED_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=_origins,
                   allow_methods=["GET", "POST"], allow_headers=["Content-Type"])

# Tiny in-memory rate limiter (per client IP) so nobody can drain your LLM key.
RATE_SIMULATE = int(os.getenv("RATE_SIMULATE", "300"))   # requests / minute / IP
RATE_TUTOR = int(os.getenv("RATE_TUTOR", "10"))
_hits: dict = collections.defaultdict(collections.deque)


def rate_limit(request: Request, bucket: str, max_calls: int, window: int = 60):
    fwd = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    ip = fwd or (request.client.host if request.client else "unknown")
    q = _hits[(bucket, ip)]
    now = time.monotonic()
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= max_calls:
        raise HTTPException(429, "Too many requests. Please wait a moment.")
    q.append(now)
    if len(_hits) > 5000:                      # keep memory bounded
        for k in [k for k, v in _hits.items() if not v or now - v[-1] > window]:
            _hits.pop(k, None)
_sim = AerSimulator(method="statevector")


class Op(BaseModel):
    col: int = Field(ge=0)
    g: Literal["X", "Y", "Z", "H", "S", "T", "CX"]
    q: int = Field(ge=0)
    c: Optional[int] = Field(default=None, ge=0)

    @model_validator(mode="after")
    def _cx_needs_control(self):
        if self.g == "CX" and (self.c is None or self.c == self.q):
            raise ValueError("CX needs a control qubit different from the target")
        return self


class Circuit(BaseModel):
    num_qubits: int = Field(ge=1, le=MAX_QUBITS)
    ops: list[Op] = Field(max_length=MAX_OPS)
    shots: int = Field(default=0, ge=0, le=MAX_SHOTS)


def build(circ: Circuit) -> QuantumCircuit:
    n = circ.num_qubits
    qc = QuantumCircuit(n)
    used: set[tuple[int, int]] = set()
    for o in sorted(circ.ops, key=lambda o: o.col):
        qubits = [o.q] + ([o.c] if o.g == "CX" else [])
        if any(x >= n for x in qubits):
            raise HTTPException(422, f"Qubit index out of range for {n} qubits")
        for x in qubits:                       # one gate per qubit per column
            if (o.col, x) in used:
                raise HTTPException(422, f"Overlapping gates on q{x} in column {o.col}")
            used.add((o.col, x))
        if o.g == "CX":
            qc.cx(o.c, o.q)
        else:
            getattr(qc, o.g.lower())(o.q)
    return qc


def bloch_vectors(sv, n):
    rho = DensityMatrix(sv)
    out = []
    for k in range(n):
        red = partial_trace(rho, [i for i in range(n) if i != k]).data
        x, y, z = 2 * red[0, 1].real, -2 * red[0, 1].imag, (red[0, 0] - red[1, 1]).real
        out.append({"qubit": k, "x": float(x), "y": float(y), "z": float(z),
                    "length": float(np.sqrt(x * x + y * y + z * z))})
    return out


@app.get("/health")
def health():
    import qiskit, qiskit_aer
    return {"status": "ok", "backend": "qiskit-aer",
            "qiskit": qiskit.__version__, "aer": qiskit_aer.__version__}


@app.post("/simulate")
def simulate(circ: Circuit, request: Request):
    rate_limit(request, "simulate", RATE_SIMULATE)
    qc = build(circ)
    n = circ.num_qubits
    sv_circ = qc.copy()
    sv_circ.save_statevector()
    sv = np.asarray(_sim.run(sv_circ).result().get_statevector())
    probs = np.abs(sv) ** 2
    resp = {
        "backend": "qiskit-aer",
        "num_qubits": n,
        "statevector": [[float(a.real), float(a.imag)] for a in sv],
        "probabilities": {format(i, f"0{n}b"): float(p)
                          for i, p in enumerate(probs) if p > 1e-9},
        "bloch": bloch_vectors(sv, n),
        "depth": qc.depth(),
        "circuit_ascii": str(qc.draw("text")),
    }
    if circ.shots:
        m = qc.copy()
        m.measure_all()
        resp["counts"] = _sim.run(m, shots=circ.shots).result().get_counts()
    return resp


# ---- LLM tutor (grounded in the simulated result) -------------------------
from fastapi.responses import FileResponse

TUTOR_SYSTEM = ("You are a friendly quantum computing tutor for beginners. Explain ONLY what the "
                "simulation results provided show. Never invent numbers or outcomes that are not in "
                "the data. A Bloch length below 1 means that qubit is entangled. Answer in under "
                "120 words, plain language, no headings.")


class TutorReq(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    context: str = Field(max_length=4000)


@app.post("/tutor")
def tutor(req: TutorReq, request: Request):
    rate_limit(request, "tutor", RATE_TUTOR)
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        raise HTTPException(503, "Tutor not configured: set ANTHROPIC_API_KEY on the server")
    import anthropic
    msg = anthropic.Anthropic(api_key=key).messages.create(
        model=os.getenv("TUTOR_MODEL", "claude-sonnet-5"), max_tokens=400, system=TUTOR_SYSTEM,
        messages=[{"role": "user", "content": f"{req.context}\n\nLearner question: {req.question}"}])
    return {"answer": msg.content[0].text}


@app.get("/", include_in_schema=False)
def index():
    page = os.path.join(os.path.dirname(__file__), "index.html")
    if not os.path.exists(page):
        raise HTTPException(404, "index.html not found next to main.py")
    return FileResponse(page)
